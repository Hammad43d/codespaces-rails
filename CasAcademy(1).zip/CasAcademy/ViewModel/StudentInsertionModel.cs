﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasAcademy.ViewModel
{
    public class StudentInsertionModel
    {
        public string StudentName { get; set; }
        public string FatherName { get; set; }   
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
