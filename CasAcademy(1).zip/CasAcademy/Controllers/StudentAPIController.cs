﻿using AutoMapper;
using CasAcademy.CASContext;
using CasAcademy.DBClasses;
using CasAcademy.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasAcademy.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAPIController : ControllerBase
    {
        CASDBContext _dbo;
        IMapper _map;
        public StudentAPIController(CASDBContext dbObject, IMapper mapObject)
        {
            _dbo = dbObject;
            _map = mapObject;
        }

        [HttpPost]
        [Route("InsertStudent")]
        public Response PostStudent(StudentInsertionModel std)
        {
            Response res = new Response();
            try
            {
                Students newStd = _map.Map<Students>(std);


                newStd.Status = 1;
                _dbo.Student.Add(newStd);
                _dbo.SaveChanges();
                res.Id = newStd.StudentId;
                res.ResponseMessage = "Inserted Successfully";
            }
            catch  (Exception ex)
            {
                res.Id = 0;
                res.ResponseMessage = ex.Message;
            }

            return res;
        }

        [HttpGet]
        [Route("GetAllStudents")]
        public List<StudentGetModel> GetAllStudents() 
        {
            List<Students> StudentList = _dbo.Student.Where(std => std.Status == 1).ToList();


            List<StudentGetModel> NewStudentList = _map.Map<List<StudentGetModel>>(StudentList);
            return NewStudentList;
        }

    }
}
