﻿using AutoMapper;
using CasAcademy.DBClasses;
using CasAcademy.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasAcademy.MappingClass
{
    public class ViewModelMapping : Profile
    {
        public ViewModelMapping ()
        {
            CreateMap<StudentInsertionModel, Students>().ReverseMap();
            CreateMap<StudentGetModel, Students>().ReverseMap();
        }
    }
}
