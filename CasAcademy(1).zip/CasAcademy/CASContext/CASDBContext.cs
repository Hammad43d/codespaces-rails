﻿using CasAcademy.DBClasses;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasAcademy.CASContext
{
    public class CASDBContext : DbContext
    {
        public CASDBContext(DbContextOptions<CASDBContext> options) : base(options)
        {
        }

        public DbSet<Students> Student { get; set; }
    }
}
